<?php

interface ICommand
{
    public function exec($arguments);
}