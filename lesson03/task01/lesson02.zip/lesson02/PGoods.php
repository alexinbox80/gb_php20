<?php

namespace alexinbox\phpv20;
require_once "Good.php";

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

class PGoods extends Good
{
    private $pgoods = [];

    function __construct($quantity)
    {
        $this->initGoods($quantity);
    }

    public function initGoods(int $count): void
    {
        $goods = ['cell phone', 'notebook', 'tablet', 'powerbank', 'watch'];
        $price = [2.15, 4.44, 5.99, 12.35, 5.45];

        for ($i = 0; $i < $count; $i++) {
            $this->pgoods[$i] = [
                'id' => $i + 1,
                'name' => $goods[rand(0, count($goods) - 1)],
                'price' => $price[rand(0, count($price) - 1)],
                'quantity' => rand(1, count($price))
            ];
        }
    }

    function showGoods(bool $debug = false): void
    {
        for ($i = 0; $i < count($this->pgoods); $i++) {
            echo "id: {$this->pgoods[$i]['id']} 
                  name: {$this->pgoods[$i]['name']} 
                  price: {$this->pgoods[$i]['price']} 
                  quantity: {$this->pgoods[$i]['quantity']} <br>\n";
        }

        if ($debug) {
            echo "<pre>";
            print_r($this->pgoods);
            echo "</pre>";
        }
    }

    public function getCost(): float
    {
        $sum = 0;

        for ($i = 0; $i < count($this->pgoods); $i++) {
            $sum += $this->pgoods[$i]['price'] * $this->pgoods[$i]['quantity'];
        }
        return $sum;
    }

    public function getFullPrice(float $price): float
    {
        return $price * 1.0;
    }
}