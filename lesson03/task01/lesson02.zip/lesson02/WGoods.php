<?php

namespace alexinbox\phpv20;
require_once "Good.php";

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

class WGoods extends Good
{
    private $wgoods = [];

    function __construct($quantity)
    {
        $this->initGoods($quantity);
    }

    public function initGoods(int $count): void
    {
        $goods = ['bred', 'buter', 'potato', 'tomatos', 'cucumbers'];
        $price = [1.15, 2.44, 3.99, 6.35, 1.44];

        for ($i = 0; $i < $count; $i++) {
            $this->wgoods[$i] = [
                'id' => $i + 1,
                'name' => $goods[rand(0, count($goods) - 1)],
                'price' => $price[rand(0, count($price) - 1)],
                'quantity' => rand(1, count($price))
            ];
        }
    }

    function showGoods(bool $debug = false): void
    {
        for ($i = 0; $i < count($this->wgoods); $i++) {
            echo "id: {$this->wgoods[$i]['id']} 
                  name: {$this->wgoods[$i]['name']} 
                  price: {$this->wgoods[$i]['price']} 
                  quantity: {$this->wgoods[$i]['quantity']} <br>\n";
        }

        if ($debug) {
            echo "<pre>";
            print_r($this->wgoods);
            echo "</pre>";
        }
    }

    public function getCost(): float
    {
        $sum = 0;
        for ($i = 0; $i < count($this->wgoods); $i++) {
            if ($this->wgoods[$i]['quantity'] >= 5) {
                $coefficient = 1.2;
            } else {
                $coefficient = 1;
            }
            $sum += $this->wgoods[$i]['price'] *  $coefficient * $this->wgoods[$i]['quantity'];
        }
        return $sum;
    }

    public function getFullPrice(float $price): float
    {
        return $price * 1.2;
    }
}