<?php
use alexinbox\phpv20 as good;

//spl_autoload_register( function ($className) {
//    require_once $className . ".php";
//});

//require_once "Goods.php";
require_once "DGoods.php";
//require_once "PGoods.php";
//require_once "WGoods.php";

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);


$dgoods = [
    ['name' => 'music', 'price' => 1.35],
    ['name' => 'book', 'price' => 2.44],
    ['name' => 'license', 'price' => 0.99],
    ['name' => 'games', 'price' => 3.35],
    ['name' => 'operating system', 'price' => 7.62]
    ];

echo "Digital products<br>\n";
$goods = new good\DGoods($dgoods, rand(1, 10));
$goods->showGoods(true);
echo "Total price: {$goods->getCost()} units.<br>\n";
echo "Full price: {$goods->getFullPrice($goods->getCost())} units.<br><br>\n";

//echo "Piece products<br>\n";
//$pgoods = new good\PGoods(rand(1, 12));
//$pgoods->showGoods();
//echo "Total price: {$pgoods->getCost()} units.<br>\n";
//echo "Full price: {$pgoods->getFullPrice($pgoods->getCost())} units.<br><br>\n";
//
//echo "Weight products<br>\n";
//$wgoods = new good\WGoods(rand(1, 15));
//$wgoods->showGoods();
//echo "Total price: {$wgoods->getCost()} units.<br>\n";
//echo "Full price: {$wgoods->getFullPrice($wgoods->getCost())} units.<br><br>\n";